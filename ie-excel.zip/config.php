<?php
    //This file contains database connection setting
    $host = "localhost";
    $user = "root";
    $pwd = "";
    $dbname="ict";
    $link = mysqli_connect($host,$user,$pwd,$dbname);
?>