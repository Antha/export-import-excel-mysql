- import database based on ict.sql

- put zip file that have been extracted into your localhost

- set configuration on config.php based your phpmyadmin database setting

- run the web (localhost/ie-excel)

- enjoy